<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Auth;
use App\User;
use App\ApiRequest;
use Illuminate\Support\Facades\DB;

class UsersController extends Controller
{
    public function index(Request $request)
    {
        $token = Auth::user()->api_token;
        if(isset($token)) {
            $user = User::where('api_token', $token)->first();
            if (count($user) > 0) {

                $apiRequest = new ApiRequest();
                $apiRequest->user_id = $user->id;
                $apiRequest->request_url = $request->url();
                if ($apiRequest->save()) {
                    return response()->json(['status' => true]);
                }
            } else {
                return response()->json(['status' => false, 'message' => 'Invalid request']);
            }
        }
    }

    public function showDashboard()
    {
        $userDetails = DB::table('users')
                ->rightJoin('api_requests', 'users.id', '=', 'api_requests.user_id')
                ->select(DB::raw('count(*) as count'), 'name')
                ->groupBy('user_id')
                ->get();

        $apiData = DB::table('api_requests')
                    ->leftJoin('users', 'users.id', '=', 'api_requests.user_id')
                    ->get(['name', 'request_url', 'users.created_at as created_at']);

        $totalRequest = count($apiData);

        return view('home', [
            'api_data' => $apiData,
            'total_request' => $totalRequest,
            'user_details' => $userDetails
        ]);
    }

    public function showUserApi()
    {
        return view('user-api');
    }
}
