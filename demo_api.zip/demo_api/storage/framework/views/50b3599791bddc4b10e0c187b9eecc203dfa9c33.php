<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <div>
                        <h4>Total Request served : <?php echo e($total_request); ?></h4>
                        <h4>Api hit count by user</h4>
                        <?php if(count($user_details) > 0): ?>
                            <?php $__currentLoopData = $user_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><?php echo e($user_detail->name); ?> : <?php echo e($user_detail->count); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                   <table id="data" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>User Name</th>
                            <th>URL</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($api_data) > 0): ?>
                            <?php $__currentLoopData = $api_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->name); ?></td>
                                    <td><?php echo e($data->request_url); ?></td>
                                    <td><?php echo e($data->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
        $(document).ready(function() {
            $.noConflict();
            $('#data').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>